//
//  EatVC.swift
//  Restaurant Roulette
//
//  Created by John Leonardo on 8/13/17.
//  Copyright © 2017 John Leonardo. All rights reserved.
//

import UIKit
import Alamofire
import CoreLocation
import SwiftyJSON
import ATHMultiSelectionSegmentedControl

class EatVC: UIViewController, MultiSelectionSegmentedControlDelegate, UITextFieldDelegate {
    
    var locationManager = CLLocationManager()
    
    @IBOutlet weak var searchField: UITextField!
    @IBOutlet weak var segment: MultiSelectionSegmentedControl!
    @IBOutlet weak var openSwitch: UISwitch!
    @IBOutlet weak var mileSlider: UISlider!
    @IBOutlet weak var mileLabel: UILabel!
    
    var searchResults = [[String:Any]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        segment.insertSegmentsWithTitles(["$", "$$", "$$$", "$$$$"])
        segment.delegate = self
        
        mileSlider.addTarget(self, action: #selector(EatVC.updateLabel(sender:)), for: .allEvents)
        
        searchField.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    //method for getting list of restaurants
    func getRestaurants(term: String, open: Bool, price: String, radius: Int) {
        if (CLLocationManager.authorizationStatus() == .authorizedWhenInUse), let lon = locationManager.location?.coordinate.longitude, let lat = locationManager.location?.coordinate.latitude {
                
                let headers: HTTPHeaders = [
//                    "Authorization": "BearerZH_ovPA7murGOl1ijwYI2omrB-fx5XJAhYDqW7yleYXD6MGixHHTTC6hNGEI1TakN8tqklcmKfpNj8nGBzv7_NiY69B8830hauSKE_4La6f9sUhPlX3eP8Xo_DAmW3Yx",
                    "Authorization": "Bearer howHTDd8ES5RxblztHtVs9edJROqgkm7cHMSehX7K9PwrQ4obr6pP6Yc76cRDBkqHrnRLbMbKZCQqww8cjUIv8-lIHEVIeii-Cuv3qvzcwlO9d1fCsjCPy1Rh--QWXYx",
                    "Accept": "application/x-www-form-urlencoded"
                ]
            
            let Latitude = 22.3223089
            let Longitude = 114.1697609

                let url = "https://api.yelp.com/v3/businesses/search?category_filter=restaurants&longitude=\(Longitude)&latitude=\(Latitude)&term=\(term)&radius=\(radius)&limit=50&open_now=\(open)&price=\(price)"
                
                print(url)
                
                Alamofire.request(url, method: .get, headers: headers).responseJSON { response in
                    //debugPrint(response)
                    
                    if let value = response.result.value {
                        let json = JSON(value)
                        //print(json)
                        
                        if json["total"] >= 3 {
                            for (_,place) in json["businesses"] {
                                let data = [
                                    "name": place["name"],
                                    "phone": place["display_phone"],
                                    "lon": "\(place["coordinates"]["longitude"])",
                                    "lat": "\(place["coordinates"]["latitude"])"
                                ] as [String : Any]
                                self.searchResults.append(data)
                            }
                            
                            self.performSegue(withIdentifier: "goToRoulette", sender: nil)
                        } else {
                            let ac = UIAlertController(title: "Oops", message: "Too few of results were found! Try modifying your spin settings!", preferredStyle: .alert)
                            ac.addAction(UIAlertAction(title: ":(", style: .cancel, handler: nil))
                            self.present(ac, animated: true, completion: nil)
                        }
                        

                    }
                }
            
        } else {
            let ac = UIAlertController(title: "Oops", message: "Your location is not enabled. Please enable location in Settings so you can use the app :)", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
            self.present(ac, animated: true, completion: nil)
        }
        
    }
    
    //required delegate method for multi segment control
    func multiSelectionSegmentedControl(_ control: MultiSelectionSegmentedControl, selectedIndices indices: [Int]) {
        
        var selectedIndices = "selected indices: ["
        
        for index in indices {
            selectedIndices.append("\(String(index)),")
        }
        
        if indices.count != 0 {
            selectedIndices = String(selectedIndices.characters.dropLast())
        }
        
        print(selectedIndices)
        
    }
    
    @IBAction func spin(_ sender: Any) {
        if searchField.text != "", let term = searchField.text {
            if segment.selectedSegmentIndices.count != 0 {
                
                var priceArray = segment.selectedSegmentIndices
                var count = 0
                
                //increase each index by one for yelp api
                for i in priceArray {
                    priceArray[count] += 1
                    count += 1
                }
                
                //convert to string
                let stringArray = priceArray.flatMap { String($0) }
                let prices = stringArray.joined(separator: ",")
                
                let radius = Int(mileSlider.value * 1609.344)
                
                //get restaurants
                getRestaurants(term: term, open: openSwitch.isOn, price: prices, radius: radius)
            } else {
                //didnt select any price options
            }
        } else {
            //search field is empty
        }
    }
    
    func updateLabel(sender: UISlider!) {
        let value = Int(sender.value)
        DispatchQueue.main.async {
            self.mileLabel.text = "\(value)"
            //print("Slider value = \(value)")
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        view.endEditing(true)
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToRoulette" {
            let vc = segue.destination as! RouletteVC
            vc.searchResults = self.searchResults
        }
    }
    
    @IBAction func back(_ sender: Any) {
        self.performSegue(withIdentifier: "unwindToMain", sender: nil)
    }
    
    
    @IBAction func unwindToEat(segue:UIStoryboardSegue) { }
}
