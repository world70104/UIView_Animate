//
//  RouletteVC.swift
//  Restaurant Roulette
//
//  Created by John Leonardo on 8/13/17.
//  Copyright © 2017 John Leonardo. All rights reserved.
//

import UIKit
import MapKit

class RouletteVC: UIViewController {
    
    @IBOutlet weak var restaurantLabel: UILabel!
    @IBOutlet weak var reSpinBtn: UIButton!
    @IBOutlet weak var mapItBtn: UIButton!
    
    @IBOutlet weak var callBtn: UIButton!
    var searchResults = [[String:Any]]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        hideButtons()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.rollRestaurants()
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    @IBAction func call(_ sender: Any) {
        let num = "\(searchResults[searchResults.count - 1]["phone"])".replacingOccurrences( of:"[^0-9]", with: "", options: .regularExpression)
        
        let scheme = "tel://" + num
        
        if let url = URL(string: scheme) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:],
                                          completionHandler: {
                                            (success) in
                                            //print("Open \(scheme): \(success)")
                })
            } else {
                let success = UIApplication.shared.openURL(url)
                //print("Open \(scheme): \(success)")
            }
        }
    }
    
    @IBAction func mapIt(_ sender: Any) {
        
        let lon = (searchResults[searchResults.count - 1]["lon"] as! NSString).doubleValue
        let lat = (searchResults[searchResults.count - 1]["lat"] as! NSString).doubleValue
        
                
        let regionDistance:CLLocationDistance = 10000
        let coordinates = CLLocationCoordinate2DMake(lat, lon)
        let regionSpan = MKCoordinateRegionMakeWithDistance(coordinates, regionDistance, regionDistance)
        let options = [
                    MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),
                    MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)
        ]
        let placemark = MKPlacemark(coordinate: coordinates, addressDictionary: nil)
        let mapItem = MKMapItem(placemark: placemark)
        
        if let name = searchResults[searchResults.count - 1]["name"] {
            mapItem.name = "\(name)"
        }
        
        mapItem.openInMaps(launchOptions: options)
        
        
    }
    
    @IBAction func reSpin(_ sender: Any) {
        rollRestaurants()
    }
    
    
    func rollRestaurants() {
        searchResults.shuffle()
        
        unhideButtons()
        
        for i in 0...searchResults.count - 1 {
            // Always update your GUI on the main thread
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) / 8) {
                if let name = self.searchResults[i]["name"] {
                    self.restaurantLabel.text = "\(name)"
                }
            }
        }
        
        UIView.animate(withDuration: 6) {
            self.callBtn.center.x = UIScreen.main.bounds.midX
            self.mapItBtn.center.x = UIScreen.main.bounds.midX
            self.reSpinBtn.center.x = UIScreen.main.bounds.midX
        }
        
        
    }
    func unhideButtons() {
        callBtn.isHidden = false
        reSpinBtn.isHidden = false
        mapItBtn.isHidden = false
    }
    
    func hideButtons() {
        callBtn.isHidden = true
        reSpinBtn.isHidden = true
        mapItBtn.isHidden = true
    }

    @IBAction func back(_ sender: Any) {
        self.performSegue(withIdentifier: "unwindToEat", sender: nil)
    }
}
