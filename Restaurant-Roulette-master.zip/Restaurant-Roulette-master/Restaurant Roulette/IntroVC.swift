//
//  IntroVC.swift
//  Restaurant Roulette
//
//  Created by John Leonardo on 8/13/17.
//  Copyright © 2017 John Leonardo. All rights reserved.
//

import UIKit

class IntroVC: UIViewController {
    
    @IBOutlet weak var yelpBanner: UIImageView!
    @IBOutlet weak var knifeImage: UIImageView!
    @IBOutlet weak var forkImage: UIImageView!
    @IBOutlet weak var rouletteImage: UIImageView!
    @IBOutlet weak var container: UIView!

    let screenSize = UIScreen.main.bounds
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.animate()
    }
    
    //no status bar
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    //function for animating the intro
    func animate() {
        UIView.animate(withDuration:0.5, animations: { () -> Void in
            
            self.rouletteImage.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
        })
        
        UIView.animate(withDuration: 0.5, delay: 0.45, options: .curveEaseIn, animations: { () -> Void in
            
            self.rouletteImage.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi * 2))
        }, completion: { (finished: Bool) in
            UIView.animate(withDuration: 2, animations: { 
                //self.knifeImage.center.x = self.container.bounds.width
                //self.forkImage.center.x = 0
                self.yelpBanner.center.y = self.container.bounds.maxY - 30
            }, completion: { (finished: Bool) in
                self.performSegue(withIdentifier: "goToMain", sender: nil)
            })
        })
    }

}

