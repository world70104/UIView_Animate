//
//  MainVC.swift
//  Restaurant Roulette
//
//  Created by John Leonardo on 8/13/17.
//  Copyright © 2017 John Leonardo. All rights reserved.
//

import UIKit
import Alamofire
import CoreLocation
import GoogleMobileAds

class MainVC: UIViewController {
    
    //yelp keys
    let client_id = "LGT0y9zNtgoZQVngJZL-Lw" // "I6pXU9ZnbA9pTwDZgQXhkQ"
    let client_secret = "hXqqOD030XRLTrXk2zhDU5RYKz8EHEaZrhG43iht0aQ2nWn7pQ63t7Z6VgEec2At"
    
    //location manager
    let locationManager = CLLocationManager()
    
    //interstitial advertisement
    var interstitial: GADInterstitial!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //request location usage
        self.locationManager.requestWhenInUseAuthorization()
        
        //ad stuff
        interstitial = GADInterstitial(adUnitID: "ca-app-pub-7147612881925877/4907518779")
        let request = GADRequest()
        interstitial.load(request)
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    @IBAction func unwindToMain(segue:UIStoryboardSegue) { }
    
    @IBAction func showSponsor(_ sender: Any) {
        if interstitial.isReady {
            interstitial.present(fromRootViewController: self)
        } else {
            let ac = UIAlertController(title: "Thank You!", message: "Thanks for wanting to support, but we don't have any sponsored ads to show at this time", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "Bummer :/", style: .cancel, handler: nil))
            self.present(ac, animated: true, completion: nil)
        }
        
    }
}
